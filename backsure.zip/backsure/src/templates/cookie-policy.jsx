import React, { Component } from 'react';
class Cookie extends Component {
    render() {
    return (
        <>
        	<h1>Cookie Policy</h1>
        </>
    );
  }
}
export default Cookie;