function Claimsmanagement() {
  return(
      <>
       <h1>Claims management</h1>
      </>    
  );
}
export default Claimsmanagement;
