import Navbar from '../components/Navbar';
function Header() {
  return (
        <>
        	<Navbar />
        </>
  	);
}
export default Header;